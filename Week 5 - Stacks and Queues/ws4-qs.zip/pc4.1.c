/* Add your stack implementation from Programming 4.1 
    and change the data type from integer to character */

/* Compresses all duplicate characters into character and
    count pairs in given input and prints the results. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void compress(char *input);

void compress(char *input){
    /* FILL IN HERE */
}

int main(int argc, char **argv){
    char *input = "Aaaaaa, screamed the amateur magician as the aardvark ate the apple he'd prepared...";
    
    compress(input);
    
    return 0;
}